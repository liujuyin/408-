import os
os.system('streamlit run web_demo.py')
